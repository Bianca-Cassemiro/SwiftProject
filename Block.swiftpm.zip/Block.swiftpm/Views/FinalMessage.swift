//
//  FinalMessage.swift
//  Block
//
//  Created by Bia on 4/18/23.
//

import SwiftUI

struct FinalMessage: View {
    @State var shouldShowContentView: Bool = false
    var body: some View {
        NavigationView {
            ZStack{
                Color(uiColor: UIColor(red: 1.00, green: 0.91, blue: 0.70, alpha: 1.0))
                    .ignoresSafeArea()
                VStack{
                    Spacer()
                
                    RoundedRectangle(cornerRadius: 30)
                        .frame(width: 800, height: 500)
                        .foregroundColor(.white)
                        .overlay(content: {
                            HStack{
                                Button(action: {}, label: {
                                    Image("Pen")
                                        .resizable()
                                        .frame(width: 80, height: 160)
                                        .padding(.trailing,40)
                                })
                                VStack(spacing: 15){
                                    Text("Thank you very much for\n accompanying me on this adventure. ")
                                        .font(.system(size: 35))
                                        .frame(width: 600)
                                        .multilineTextAlignment(.center)
                                        .foregroundColor(.blue)
                                    Text("During this journey, we uncovered the realm of Ethereum... however, there are several other realms to explore, such as the realm of Polygon and the realm of Celo, for example. Will I see you there?")
                                        .font(.system(size: 33))
                                        .frame(width: 600)
                                        .multilineTextAlignment(.center)
                                        
                                    }
                            }
                            
                        })
                   
                        Spacer()
                    NavigationLink(destination:ContentView(), isActive: $shouldShowContentView) {
                        EmptyView()
                        
                        VStack(spacing: 10){
                            
                            Image("Block")
                                .resizable()
                                .frame(width: 300,height: 250)
                                .padding()
                            
                            
                            
                            Button(action: {
                                self.shouldShowContentView = true
                            }, label:
                                    {
                                Circle()
                                    .fill(.white)
                                    .frame(width: 130, height: 150)
                                    .shadow(color: .gray,radius: 10)
                                    .padding()
                                    .overlay(content: {
                                        Image(systemName: "homekit")
                                            .font(.system(size: 70))
                                            .foregroundColor(.black)
                                            .opacity(0.7)
                                    })
                                
                                
                            })}}
                        Spacer()
                    
                }
            }
        }         .navigationViewStyle(StackNavigationViewStyle())
            .navigationBarHidden(true)

    }
}

struct FinalMessage_Previews: PreviewProvider {
    static var previews: some View {
        FinalMessage()
    }
}
