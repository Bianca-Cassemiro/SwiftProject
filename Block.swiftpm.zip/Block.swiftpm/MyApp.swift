import SwiftUI

@main
struct Block: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
